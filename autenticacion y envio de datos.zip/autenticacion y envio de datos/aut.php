<?php
function autenticar($documento, $clave) {
    $salida=0;
    $conexion = new mysqli('127.0.0.1', 'root', 'root', 'registro');

    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    $sq = "SELECT COUNT(nombre) FROM personas WHERE documento = '$documento' AND clave = '$clave'";


   
    $resultado = $conexion->query($sq);

    $conexion->close();

   
    $fila = mysqli_fetch_array($resultado);
    $salida=$fila[0];
    return $salida;
     
   

}
function mostrar($documento,){
    $salida='';
    $conexion = mysqli_connect('127.0.0.1', 'root', 'root', 'registro');
    $sq = "SELECT * FROM personas WHERE documento = '$documento'";
    $resultado = $conexion->query($sq);

    while ($fila = mysqli_fetch_array($resultado)) {
        $salida .= $fila[0] .'<br>';
        $salida .= $fila[1] .'<br>';
        $salida .= $fila[2] .'<br>';
        $salida .= '<br>';
    }
   
    $conexion->close();

    return $salida;
}
