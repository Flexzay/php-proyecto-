<?php
include('incriptar.php');

function registro($documento)
{
    $nombre = '';
    $salida = "";
    $conexion = mysqli_connect('localhost', 'root', 'root', 'registro');

    
    if (!$conexion) {
        die("Error al conectar a la base de datos:" . mysqli_connect_error());
    }

    $sq = "SELECT nombre FROM personas WHERE Documento='$documento'";
    $resultado = mysqli_query($conexion, $sq);

    while ($fila = mysqli_fetch_array($resultado)) {
        $salida .= $fila[0];
    }


    mysqli_close($conexion);

    $nombre = desencriptar($salida);

    return $nombre;
}

echo registro('10');
