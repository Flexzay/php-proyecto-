<?php

include('aut.php');

$u = $_GET['cc'];
$s = $_GET['pass'];

if (autenticar($u, $s) == 1) {
    echo "Redirigiendo a a2.php";
    header("location:a2.php?cc=$u&pass=$s");
    exit;
} else {
    echo "Redirigiendo a a3.php";
    header("location:a3.php");
    exit;
}
?>
