
<?php

include("incriptar.php");

function registro($documento, $nombre, $clave)
{
    $salida = "";
    $conexion = mysqli_connect('localhost', 'root', 'root', 'registro');

    // verificacion de conexion
    if (!$conexion) {
        die("Error al conectar a la base de datos:" . mysqli_connect_error());
    }

    $clave= encriptar($clave);
    $nombre= encriptar($nombre);

    $sq = "INSERT INTO personas (documento, nombre, clave) VALUES ('$documento', '$nombre', '$clave')";

    

    // Ejecutar la consulta
    $resultado = $conexion->query($sq);

    if ($resultado) {
        $salida = "Registro exitoso";
    } else {
        $salida = "Error en el registro: " . $conexion->error;
    }

    $conexion->close();

    return $salida;
}


echo registro("10", "enrique  ", "1010");



?>

