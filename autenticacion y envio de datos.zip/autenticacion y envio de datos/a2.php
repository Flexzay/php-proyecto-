<?php

include('aut.php');

$u = $_GET['cc'];
echo mostrar($u);
?>
<a href="muestra.php">MOSTRAR_USUARIOS</a>