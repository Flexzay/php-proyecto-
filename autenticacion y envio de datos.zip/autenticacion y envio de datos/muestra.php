<?php
function mostrar1()
{
    $salida = '';
    $conexion = mysqli_connect('127.0.0.1', 'root', 'root', 'registro');
    $sq = "SELECT * FROM personas";
    $resultado = $conexion->query($sq);

    while ($fila = mysqli_fetch_array($resultado)) {
        $salida .= $fila[0] . '<br>';
        $salida .= $fila[1] . '<br>';
        $salida .= $fila[2] . '<br>';
        $salida .= '<br>';
    }

    $conexion->close();

    return $salida;
}

echo mostrar1();